<html lang="en">
<style>
    <?php include "CSS/style.css" ?>
</style>
<head>
    <?php include ("Shared/navbar.xhtml"); ?>
    <title>College Events - Home Page</title>
</head>
<body>
    <h1>Welcome to the College Event Website</h1>
    <p>Please See the Navigation Bar for Available Actions</p>
    <h1>Site Information: </h1>
    <ul>
        <li>Only Super Administrators Can Register a School</li>
        <li>Only Administrators Can Create an Event</li>
        <li>Students Are Permitted to View Events</li>
    </ul>
</body>
</html>
